<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="../imagens/loja.ico">
    <title>Login page</title>
</head>
<body>
<main>
<header><!--Links--> 
    <ul id='menu'>
    <li id='logo'><a href="../index.php">BESTSTORE</a></li>
        <li><a href="singIn.php">Sing in</a></li>
        <li><a href="singUp.php">Sing up</a></li>
    </ul>
    </header>
    <div id="divisoria"></div>  
    <section>
    <h3>Login</h3>
    <?php
        if(isset($_SESSION['msg'])):
            echo $_SESSION['msg'];
            unset ($_SESSION['msg']);
        
        endif;
        ?>
        <form action="login.php" method="POST">
        <input type="email" name='email_User' id='email_User' placeholder='Email'>
        <input type="password" name='passw_User' id='passw_User' placeholder='Password'> 
        <input type="submit" value="Sing in" id='signin'>
        </form>
        
    </section>
    
</main>
<footer>
        <p>&copyVendeTudoCorporation</p>
    </footer>
</body>
</html>