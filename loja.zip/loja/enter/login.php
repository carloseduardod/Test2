<?php
    require ("../connect/connect.php");
    if(isset($_POST['email_User']) && isset($_POST['passw_User']) && $connect != null){
        $query = $connect->prepare("SELECT * FROM users WHERE email_User = ? AND passw_User = ?"); //verificando se existe no banco de dados;
        $query->execute(array($_POST['email_User'],$_POST['passw_User']));
        
        if($query->rowCount()){
            $user = $query->fetchAll(PDO::FETCH_ASSOC)[0]; 
            session_start();
            $_SESSION['user_'] = array($user["name_User"],$user["admin"],$user['id_code_User'],$user['cpf_User'],$user['email_User']);

            header("Location: /./loja/dashboard.php");
        }else{
            $_SESSION['msg'] = '<h5>LOGIN INVALIDO</h5>';
            header("Location:singin.php");
        }
} else{
    $_SESSION['msg'] = '<h5>LOGIN INVALIDO</h5>';
    header("Location: singin.php");
}











?>