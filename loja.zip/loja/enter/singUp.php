<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="../imagens/loja.ico">
    <title>Register page</title>
</head>
<body lang='en'>
   <main>
    <header><!--Links--> 
    <ul id='menu'>
        <li id='logo'><a href="../index.php">BESTSTORE</a></li>
        <li><a href="singIn.php">Sing in</a></li>
        <li><a href="singUp.php">Sing up</a></li>
    </ul>
    </header>
    <div id="divisoria"></div>  
    <section>
        <div id="box">
            
        <h3>Register</h3>
        <?php
        if(isset($_SESSION['msg'])):
            echo $_SESSION['msg'];
            unset ($_SESSION['msg']);
        else: echo "<p>Faça o registro</p> <br>";
        endif;
        ?>
        <form name="add_User" action="register.php" method="POST">
        <input type='text' name='name_User' id='name_User' placeholder='Name' required>
        <input type="email" name='email_User' id='email_User' placeholder='Email' required>
        <input type="password" name='passw_User' id='passw_User' placeholder='Password' required>
        <input type="text" name='phone_User' id='phone_User' placeholder='Phone Number' required> 
        <input type="text" name='cpf_User' id='cpf_User' placeholder='CPF' required> 
        <input type="text" name='home_address_User' id='home_address_User' placeholder='Home Address' required> 
        <input type="submit" value="Register" name='SendAdd_User' id='signin'>
        </form>
    </div>
    </section>
  
    </main>
    <footer>
        <p>&copyVendeTudoCorporation</p>
    </footer>
</body>
</html>