<?php
session_start();
require ("../connect/connect.php");

$user = filter_input_array(INPUT_POST);
if(!empty($user['SendAdd_User'])):
    var_dump($user);
    $query_Add_User = "INSERT INTO users (name_User, email_User, passw_User, phone_User , cpf_User , home_address_User, date) VALUES (:name_User, :email_User, :passw_User, :phone_User , :cpf_User , :home_address_User,NOW())";
    $add_User = $connect->prepare($query_Add_User);
    $add_User->bindParam(':name_User',$user['name_User'], PDO::PARAM_STR);
    $add_User->bindParam(':email_User',$user['email_User'], PDO::PARAM_STR);
    $add_User->bindParam(':passw_User',$user['passw_User'], PDO::PARAM_STR);
    $add_User->bindParam(':phone_User',$user['phone_User'], PDO::PARAM_STR);
    $add_User->bindParam(':cpf_User',$user['cpf_User'], PDO::PARAM_STR);
    $add_User->bindParam(':home_address_User',$user['home_address_User'], PDO::PARAM_STR);
    $add_User->execute();        
    if($add_User->rowCount()):
            $_SESSION['msg'] = "<h5 style='color:green'>Successfully registered user!</h5><br>";
            header("Location: singUp.php");
        else: 
            $_SESSION['msg'] = "<h5 style='color:red'>Not registered user!</h5><br>";
            header("Location: singUp.php");
        endif;
    
    endif;

?>