const items = [
    {
        id:0,
        preco: 100.00,
        nome: 'CAMISA',
        img: 'imagens/./catalogo/camisa.jpg',
        descricao: 'descriçao produto, apenas textando o espaçamento e o tamanho da imagem',
        quantidade: 0
    },
    {
        id:1,
        nome: 'SHORT',
        preco: 35.00,
        img: 'imagens/./catalogo/short.jpg',
        descricao: 'descriçao produto, apenas textando o espaçamento e o tamanho da imagem',
        quantidade: 0
    },
    {
        id:2,
        nome: 'TENIS',
        preco: 350.00,
        img: 'imagens/./catalogo/tenis.jpg',
        descricao: 'descriçao produto, apenas textando o espaçamento e o tamanho da imagem',
        quantidade: 0
    },
    
];

    inicializarLoja = () => {
        var containerProduto = document.getElementById('produtos');
        items.map((val)=>{
            containerProduto.innerHTML += `
            <div class="produto-single">
                <img src="${val.img}"/>
                <h4>${val.nome}</h4>
                <p>${val.descricao}</p>
                <h3>R$ ${val.preco}</h3>
                <a href="#" key="${val.id}" class="carrinho">Adicionar ao carrinho</a>
            </div> 
            `
            
        });
    }
    inicializarLoja();
    atualizarCarrinho = () => {
        var containerCarrinho = document.getElementById('carrinho');
        containerCarrinho.innerHTML =""; 
        items.map((val)=>{
            if(val.quantidade>0){
            containerCarrinho.innerHTML += `
                <li class='lista-carrinho'> ${val.nome} (${val.quantidade})</li>
                `;
            } 
            
        
    });
    }
    

    var produtosAdicionados = document.getElementsByClassName("carrinho");
    for(var i = 0 ; i < produtosAdicionados.length; i++){
          produtosAdicionados[i].addEventListener("click",function(){
          let key = this.getAttribute('key');
          items[key].quantidade++;
          atualizarCarrinho();
          return false;

        });
    }


   