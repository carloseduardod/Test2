
const items = [console.log('<?php ?>')];

    inicializarLoja();
    atualizarCarrinho = () => {
        var containerCarrinho = document.getElementById('carrinho');
        containerCarrinho.innerHTML =""; 
        items.map((val)=>{
            if(val.quantidade>0){
            containerCarrinho.innerHTML += `
                <li class='lista-carrinho'> ${val.nome} (${val.quantidade})</li>
                `;
            } 
            
        
    });
    }
    

    var produtosAdicionados = document.getElementsByClassName("carrinho");
    for(var i = 0 ; i < produtosAdicionados.length; i++){
          produtosAdicionados[i].addEventListener("click",function(){
          let key = this.getAttribute('key');
          items[key].quantidade++;
          atualizarCarrinho();
          return false;

        });
    }


   