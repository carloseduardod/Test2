<?php

    $host = "127.0.0.1"; //OU localhost
    $user = "root"; //usuario
    $passw = ""; //senha
    $bd = "store"; //banco de dados

   try {
    $connect = new PDO ("mysql:host=$host;dbname=".$bd, $user, $passw); 
    $connect -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    print "<script>console.log('Connection made successfully')</script>";
    } catch (PDOException $erro){
    print "<script>console.log('Error - Connection not made')</script>";
    $connect = null;
    }
