<?php
//verfica se o usuario esta logado

session_start();
require('../connect/connect.php');
if (isset($_SESSION['user_'])):
    $adm = $_SESSION['user_'][1];
    $nome = $_SESSION['user_'][0];
else:
    echo "<script>window.location = '../erro.html'</script>";
endif;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/style.css" rel="stylesheet">
    <link href="../styles/formal.css" rel="stylesheet">
    <link rel="shortcut icon" href="../imagens/loja.ico">
    <title>Registros</title>
</head>
<body>
    <main>
    <header><!--Links--> 
    <ul id='menu'>
    <li id='logo'><a href="../dashboard.php">BESTSTORE</a></li>
        <li><a href="#"><img src="../imagens/configuracao.png" id='hamburg'></a></li>
         <?php if ($adm == 1):
        endif;
            ?>
        <li><a href="../dashboard.php">Olá, <?php echo $nome;?></a></li>
    </ul>
    </header>
    <div id="divisoria"></div> 
    <?php if ($adm == 1): ?>
    
    <table>
    <caption>Usuarios registrados</caption>
        <thead>
            <tr><td class='cabeca'>Email</td>
                <td class='cabeca'>Senha</td>
                <td class='cabeca'>Nome</td>
                <td class='cabeca'>Telefone</td>
                <td class='cabeca'>CPF</td>
                <td class='cabeca'>Endereço</td>
                <td class='cabeca'>Nivel de acesso</td>
            </tr>
        </thead>
        <tbody>
        
            <?php
                $query = $connect->prepare("SELECT * FROM users"); //verificando se existe no banco de dados;
                $query->execute();
                $users = $query->fetchAll(PDO::FETCH_ASSOC); 
                for ($i = 0; $i < sizeof($users);$i++): // sizeof = tamanho do array
                    $currentUser = $users[$i];
            ?>
            <tr>
            <td><?php echo $currentUser ['email_User']?></td>
                <td><?php echo $currentUser ['passw_User']?></td>
                <td><?php echo $currentUser ['name_User']?></td>
                <td><?php echo $currentUser ['phone_User']?></td>
                <td><?php echo $currentUser ['cpf_User']?></td>
                <td><?php echo $currentUser ['home_address_User']?></td>
                <td><?php echo $currentUser ['admin']?></td>
                
            </tr>   
            <?php endfor; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php if ($adm == 0):
    echo "<h5><img src='../imagens/erro.png'></h5>";
    endif;
    ?>
    <p id='volt'><a href='../dashboard.php'>Voltar<a></p>
    </main>
    <footer><p>&copyVendeTudoRegistros</p></footer>
</body>
</html>