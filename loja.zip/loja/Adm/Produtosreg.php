<?php
//verfica se o usuario esta logado

session_start();
require('../connect/connect.php');
if (isset($_SESSION['user_'])):
    $adm = $_SESSION['user_'][1];
    $nome = $_SESSION['user_'][0];
else:
    echo "<script>window.location = '../erro.html'</script>";
endif;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/style.css" rel="stylesheet">
    <link href="../styles/formal.css" rel="stylesheet">
    <link rel="shortcut icon" href="../imagens/loja.ico">
    <title>Registros</title>
</head>
<body>
    <main>
    <header><!--Links--> 
    <ul id='menu'>
    <li id='logo'><a href="../dashboard.php">BESTSTORE</a></li>
        <li><a href="#"><img src="../imagens/configuracao.png" id='hamburg'></a></li>
         <?php if ($adm == 1):
        endif;
            ?>
        <li><a href="../dashboard.php">Olá, <?php echo $nome;?></a></li>
    </ul>
    </header>
    <div id="divisoria"></div> 
    <?php if ($adm == 1): ?>
    <h5>Todos os produtos registrados até o momento.</h5>
    <table>
    <caption>Produtos registrados</caption>
        <thead>
            <tr>
            <td class='cabeca'>id</td>
                <td class='cabeca'>Nome</td>
                <td class='cabeca'>Preço</td>
                <td class='cabeca'>Quantidade</td>
                <td class='cabeca'>Descrição</td>
                <td class='cabeca'>NomeDeArquivo</td>
                <td class='cabeca'>DataDeRegistro</td>
            </tr>
        </thead>
        <tbody>
        
            <?php
                $query = $connect->prepare("SELECT * FROM produtos"); //verificando se existe no banco de dados;
                $query->execute();
                $users = $query->fetchAll(PDO::FETCH_ASSOC); 
                for ($i = 0; $i < sizeof($users);$i++): // sizeof = tamanho do array
                    $currentUser = $users[$i];
            ?>
            <tr>
            <td><?php echo $currentUser ['id_produto']?></td>
                <td><?php echo $currentUser ['nome_produto']?></td>
                <td><?php echo $currentUser ['preco_produto']?></td>
                <td><?php echo $currentUser ['quantidade_produto']?></td>
                <td><?php echo $currentUser ['descricao_produto']?></td>
                <td><?php echo $currentUser ['arquivo']?></td>
                <td><?php echo $currentUser ['date_produto']?></td>
                
            </tr>   
            <?php endfor; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php if ($adm == 0):
    echo "<h5><img src='../imagens/erro.png'></h5>";
    endif;
    ?>
    <p id='volt'><a href='../dashboard.php'>Voltar<a></p>
    </main>
    <footer><p>&copyVendeTudoRegistros</p></footer>
</body>
</html>