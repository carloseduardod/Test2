<?php
//verfica se o usuario esta logado
session_start();
require('../connect/connect.php');
if (isset($_SESSION['user_'])):
    $adm = $_SESSION['user_'][1];
    $nome = $_SESSION['user_'][0];
else:
    echo "<script>window.location = '../erro.html'</script>";
endif;


$produto = filter_input_array(INPUT_POST);
$nome_imagem = $_FILES['arquivo']['name'];
$formatosPermitidos = array('png','jpeg','jpg','gif');
$extensao = pathinfo($_FILES['arquivo']['name'],PATHINFO_EXTENSION);
$novo_nome = uniqid().".$extensao";
if(!empty($produto['SendAdd_Produto'])):
    echo '<pre>';
    var_dump($produto);
    echo '</pre>';
    $query_Add_Produto = "INSERT INTO produtos (nome_produto, preco_produto, quantidade_produto, descricao_produto, arquivo ,date_produto) VALUES (:nome_produto, :preco_produto, :quantidade_produto, :descricao_produto,:arquivo,NOW())";
    $add_Produto = $connect->prepare($query_Add_Produto);
    $add_Produto->bindParam(':nome_produto',$produto['nome_produto']);
    $add_Produto->bindParam(':preco_produto',$produto['preco_produto']);
    $add_Produto->bindParam(':quantidade_produto',$produto['quantidade_produto']);
    $add_Produto->bindParam(':descricao_produto',$produto['descricao_produto']);
    $add_Produto->bindParam(':arquivo', $novo_nome );
    //verificar se os dados foram inseridos no banco de dados com sucesso
    if($add_Produto->execute()):
        
       //Diretorio
       $pasta = '../imagens/catalogo/'; 
       if(move_uploaded_file($_FILES['arquivo']['tmp_name'],$pasta.$novo_nome)):
        $_SESSION['msg'] = "<h5 style='color:green'>Produto cadastrado com sucesso!<h5/>";
        header("Location: addProdutos.php");
       else:   $_SESSION['msg'] = "<h5 style='color:red'>ERROR-IMAGEM NÃO ENVIADA<h5/>";
       header("Location: AddProdutos.php");
    endif;
       
    else:
        $_SESSION['msg'] = "<h5 style='color:red'>ERRO ao adicionar produto<h5/>";
            header("Location: AddProdutos.php");
    endif;
endif;

    
    
    
    

?>
