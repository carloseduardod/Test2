<?php
//verfica se o usuario esta logado

session_start();
require('../connect/connect.php');
if (isset($_SESSION['user_'])):
    $adm = $_SESSION['user_'][1];
    $nome = $_SESSION['user_'][0];
else:
    echo "<script>window.location = '../erro.html'</script>";
endif;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        p#align{
            text-align:center;
        }
        img#imgPhoto {
        margin-top:10px;
        margin-bottom:10px;
        height:200px;
        width:200px;
        padding:10px;
        background-color:rgb(107, 181, 250);
        border:3px solid #fff;
        border-radius:20px;
        cursor:pointer;
        transition:background .3s;
    }
    #imgPhoto:hover{
		background-color:rgb(43, 148, 247);
		}
    #flImage {
        display:none;
    }

    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/style.css" rel="stylesheet">
    <link href="../styles/formal.css" rel="stylesheet">
    <link rel="shortcut icon" href="../imagens/loja.ico">
    <title>Adicionar Produtos</title>
</head>
<body>
    <main>
    <header><!--Links--> 
    <ul id='menu'>
    <li id='logo'><a href="../dashboard.php">BESTSTORE</a></li>
        <li><a href="#"><img src="../imagens/configuracao.png" id='hamburg'></a></li>
         <?php if ($adm == 1):
        endif;
            ?>
        <li><a href="../dashboard.php">Olá, <?php echo $nome;?></a></li>
    </ul>
    </header>
    <div id="divisoria"></div> 
    <?php if ($adm == 1): ?>

             <h3>Adicionar produtos</h3>
             <?php
        if(isset($_SESSION['msg'])):
            echo $_SESSION['msg'];
            unset ($_SESSION['msg']);
        else: echo "<p id='align'><i>Adicione aqui</i></p> <br>";
        endif; ?>    		
        <form action="adicionar.php" method="POST" name='add_Produto' enctype='multipart/form-data'>
        
        <input type="text" name="nome_produto" placeholder="NOME" required>
        <input type="Number" name="preco_produto" placeholder="VALOR">
        <input type="number" name="quantidade_produto" placeholder="QUANTIDADE" required>
        <input type="text" name="descricao_produto" placeholder="DESCRICAO" required>
        <div id='recebe-arquivo'>
        <div id="arquivo-container">
		<img src="../imagens/cam.png" alt="selecione uma imagem" id="imgPhoto">
		</div> 
        <input type="file" name="arquivo" id='flImage'>
        <script src="../Scripts/foto.js"></script>
        </div>

        <input type="submit" value="Cadastrar" name='SendAdd_Produto' id='signin'>
		<br>
		
    </form>
    
    
          

       
    <?php endif; ?>
    <?php if ($adm == 0):
    echo "<h5><img src='../imagens/erro.png'></h5>";
    endif;
    ?>
    <p id='volt'><a href='../dashboard.php'>Voltar<a></p>
    </main>
    <footer><p>&copyVendeTudoRegistros</p></footer>
</body>
</html>